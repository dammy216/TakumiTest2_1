﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TakumiTest2_1
{
    internal class Carrot : Vegetable
    {
        public override string Name { get; set; }
        public override int Price { get; set; }
    }
}
