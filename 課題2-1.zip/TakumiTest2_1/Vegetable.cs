﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TakumiTest2_1
{
    abstract class Vegetable
    {
        public abstract string Name { get; set; }
        public abstract int Price { get; set; }
    }
}
